#!/usr/bin/env python

from setuptools import setup
from setuptools.command.install import install as _install

class install(_install):
    def pre_install_script(self):
        pass

    def post_install_script(self):
        pass

    def run(self):
        self.pre_install_script()

        _install.run(self)

        self.post_install_script()

if __name__ == '__main__':
    setup(
        name = 'vaultHelper',
        version = '1.1.0',
        description = '''Command-line utility for vault secrets and policies management''',
        long_description = '''
https://github.com/otto-de/vaultHelper
-----
The vaultHelper is a command-line utility written in python for managing easily vault secrets and policies in an easy manner.

Links
`````
* vaultHelper Github repository <https://github.com/otto-de/vaultHelper>
''',
        author = "José Mejía",
        author_email = "jose.mejia@otto.de",
        license = 'Apache Software License',
        url = 'https://github.com/otto-de/vaultHelper',
        scripts = ['scripts/myvault.py'],
        packages = ['vaultHelper'],
        py_modules = ['__init__'],
        classifiers = [
            'Development Status :: 3 - Alpha',
            'Programming Language :: Python'
        ],
        entry_points = {},
        data_files = [],
        package_data = {},
        install_requires = [
            'click==6.6',
            'hvac==0.2.16',
            'pyhcl==0.2.2',
            'requests==2.12.3',
            'colorama==0.3.7',
            'config==0.3.9'
        ],
        dependency_links = [],
        zip_safe=True,
        cmdclass={'install': install},
    )

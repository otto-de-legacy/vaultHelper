#!python
from vaultHelper.VaultApp import cli

if __name__ == '__main__':
    cli()



